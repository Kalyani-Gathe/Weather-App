import { useState } from "react";

function App() {
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");

  const askWeather = async () => {
    try {
      const response = await fetch("http://127.0.0.1:8000/ask", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ message: question }),
      });

      const data = await response.json();
      setAnswer(data.response);
    } catch (error) {
      setAnswer("Backend not reachable. Is it running?");
    }
  };

  return (
    <div style={{ padding: "40px", fontFamily: "Arial" }}>
      <h2>🌦 Weather App</h2>

      <input
        type="text"
        placeholder="Ask weather (e.g. Weather in Pune)"
        value={question}
        onChange={(e) => setQuestion(e.target.value)}
        style={{ width: "300px", padding: "10px" }}
      />

      <br /><br />

      <button onClick={askWeather} style={{ padding: "10px" }}>
        Get Weather
      </button>

      <p style={{ marginTop: "20px", fontSize: "18px" }}>
        {answer}
      </p>
    </div>
  );
}

export default App;

