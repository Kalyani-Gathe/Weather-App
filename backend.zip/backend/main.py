import os
import re
from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import requests

# Load .env
load_dotenv()

app = FastAPI()

# CORS for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

WEATHER_API_KEY = os.getenv("WEATHER_API_KEY")
print("WEATHER_API_KEY:", WEATHER_API_KEY)


class UserQuery(BaseModel):
    message: str

# ✅ SIMPLE & RELIABLE CITY EXTRACTION
def extract_city(message: str) -> str:
    # Convert to lowercase
    message = message.lower()

    # Remove punctuation
    message = re.sub(r"[^\w\s]", "", message)

    # Common words to ignore
    ignore_words = {
        "what", "is", "the", "weather", "of", "in",
        "today", "tell", "me", "how", "current"
    }

    words = message.split()

    # Pick last meaningful word as city
    for word in reversed(words):
        if word not in ignore_words:
            return word.capitalize()

    return ""

def get_weather(city: str):
    url = (
        f"https://api.openweathermap.org/data/2.5/weather"
        f"?q={city}&appid={WEATHER_API_KEY}&units=metric"
    )

    res = requests.get(url).json()

    if res.get("main"):
        temp = res["main"]["temp"]
        desc = res["weather"][0]["description"]
        return f"It is {temp}°C in {city} with {desc}"

    return "City not found. Please try another city."

@app.post("/ask")
def ask_weather(query: UserQuery):
    city = extract_city(query.message)

    if not city:
        return {"response": "Could not detect city. Please try again."}

    weather = get_weather(city)
    return {"response": weather}
